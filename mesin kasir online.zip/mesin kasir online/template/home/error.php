<?php
	echo informasi('negative','Halaman tidak ditemukan');
?>
