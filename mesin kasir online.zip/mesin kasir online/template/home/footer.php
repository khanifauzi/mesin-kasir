
<?php
  include_once('template/footer.php');
?>
