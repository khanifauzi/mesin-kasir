  </div>
</div>

  <script src='<?php echo base_url('assets/js/jquery.min.js'); ?>'></script>
  <script src='<?php echo base_url('assets/datatable/datatables.min.js'); ?>'></script>
  <script src='<?php echo base_url('assets/semantic/semantic.min.js'); ?>'></script>
  <script src='<?php echo base_url('assets/js/jquery.are-you-sure.js'); ?>'></script>
  <script src='<?php echo base_url('assets/js/global.js'); ?>'></script>
  <script src='<?php echo base_url('assets/js/admin.js'); ?>'></script>
  </body>
</HTML>
