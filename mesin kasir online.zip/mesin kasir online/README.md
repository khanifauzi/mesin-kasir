# Manual Payment Online Store
Toko Online yang menggunkan payment manual

Payment menggunakan informasi pembayaran pada database
